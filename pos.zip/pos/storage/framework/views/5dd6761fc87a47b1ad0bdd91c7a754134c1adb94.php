<!-- resources/views/admin/stock/sold.blade.php -->


<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Sold Out Stock</h1>
        <table class="table">
            <thead>
                <tr>
                    <th>Item Name</th>
                    <th>Sold Quantity</th>
                    <th>Date Sold</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $soldItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->item_name); ?></td>
                        <td><?php echo e($item->sold_quantity); ?></td>
                        <td><?php echo e($item->date_sold); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Downloads\unilakefinalyearproject-main\unilakefinalyearproject-main\resources\views/admin/stock/sold.blade.php ENDPATH**/ ?>