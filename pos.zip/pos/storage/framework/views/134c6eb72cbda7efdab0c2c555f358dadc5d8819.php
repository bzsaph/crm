<!-- resources/views/admin/stock/create_edit.blade.php -->


<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1><?php echo e(isset($stock) ? 'Edit' : 'Add'); ?> Stock</h1>
        <form action="<?php echo e(isset($stock) ? route('stock.update', $stock->id) : route('stock.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php if(isset($stock)): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>
        
            <div class="form-group">
                <label for="item_name">Item Name</label>
                <input type="text" class="form-control" id="item_name" name="item_name" value="<?php echo e($stock->item_name ?? ''); ?>" required>
            </div>
        
            <div class="form-group">
                <label for="quantity">Quantity</label>
                <input type="number" class="form-control" id="quantity" name="quantity" value="<?php echo e($stock->quantity ?? ''); ?>" required>
            </div>
        
            <div class="form-group">
                <label for="remaining_stock">Remaining Stock</label>
                <input type="number" class="form-control" id="remaining_stock" name="remaining_stock" value="<?php echo e($stock->remaining_stock ?? ''); ?>" required>
            </div>
        
            <div class="form-group">
                <label for="loged_in_id">Logged In User ID</label>
                <input type="number" class="form-control" id="loged_in_id" name="loged_in_id" value="<?php echo e(auth()->user()->id); ?>" readonly>
            </div>
        
            <button type="submit" class="btn btn-primary"><?php echo e(isset($stock) ? 'Update' : 'Add'); ?> Stock</button>
            <a href="<?php echo e(route('stock.index')); ?>" class="btn btn-secondary">Cancel</a>
        </form>
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Downloads\unilakefinalyearproject-main\pos\resources\views/admin/stock/create_edit.blade.php ENDPATH**/ ?>