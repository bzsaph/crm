

<?php $__env->startSection('content'); ?>
<section class="section-container">
    <div class="content-wrapper">
        <div class="content-heading">
            <div>All Companies</div>
        </div>
        <div class="container-fluid">
            <div class="card">
                <div class="card-header">
                    <div class="card-title">List of Companies</div>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Address</th>
                                <th>Phone</th>
                                <th>Email</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($company->name); ?></td>
                                <td><?php echo e($company->address); ?></td>
                                <td><?php echo e($company->phone); ?></td>
                                <td><?php echo e($company->email); ?></td>
                                <td><?php echo e(ucfirst($company->status)); ?></td>
                                <td>
                                    <a href="<?php echo e(route('companies.edit', $company->id)); ?>" class="btn btn-primary">Edit</a>
                                    <a href="<?php echo e(route('companies.show', $company->id)); ?>" class="btn btn-info">View</a>
                                    <form action="<?php echo e(route('companies.updateStatus', $company->id)); ?>" method="POST" style="display:inline-block;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <input type="hidden" name="status" value="<?php echo e($company->status === 'active' ? 'closed' : 'active'); ?>">
                                        <button type="submit" class="btn btn-warning"><?php echo e($company->status === 'active' ? 'Disable' : 'Activate'); ?></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Downloads\unilakefinalyearproject-main\unilakefinalyearproject-main\resources\views/admin/companies/index.blade.php ENDPATH**/ ?>