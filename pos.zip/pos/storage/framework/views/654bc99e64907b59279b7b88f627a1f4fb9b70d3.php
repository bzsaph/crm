<!-- resources/views/admin/stock/index.blade.php -->


<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Stock Intake</h1>
        <a href="<?php echo e(route('stock.create')); ?>" class="btn btn-primary">Add New Stock</a>
        <table class="table">
            <thead>
                <tr>
                    <th>Item Name</th>
                    <th>Quantity</th>
                    <th>Remaining Stock</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($stock->item_name); ?></td>
                        <td><?php echo e($stock->quantity); ?></td>
                        <td><?php echo e($stock->remaining_stock); ?></td>
                        <td>
                            <a href="<?php echo e(route('stock.edit', $stock->id)); ?>" class="btn btn-info">Edit</a>
                            <a href="<?php echo e(route('stock.sold', $stock->id)); ?>" class="btn btn-success">Mark as Sold</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Downloads\unilakefinalyearproject-main\pos\resources\views/admin/stock/index.blade.php ENDPATH**/ ?>