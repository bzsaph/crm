

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="mb-4">Edit Sale</h2>

    <!-- Display validation errors -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('sales.update', $sale->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="mb-4">
            <label for="client_id" class="form-label">Client</label>
            <select name="client_id" id="client_id" class="form-select" required>
                <option value="">Select a client</option>
                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($client->id); ?>" <?php echo e($sale->client_id == $client->id ? 'selected' : ''); ?>><?php echo e($client->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div id="products-container">
            <?php $__currentLoopData = $sale->soldProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="product mb-4 border p-3 rounded">
                    <h5 class="mb-3">Product Details</h5>
                    <div class="mb-3">
                        <label for="stock_id" class="form-label">Product</label>
                        <select name="products[<?php echo e($index); ?>][stock_id]" class="form-select stock_id" required>
                            <option value="">Select a product</option>
                            <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($stock->id); ?>" <?php echo e($product->stock_id == $stock->id ? 'selected' : ''); ?>><?php echo e($stock->item_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="quantity" class="form-label">Quantity</label>
                        <input type="number" name="products[<?php echo e($index); ?>][quantity]" class="form-control quantity" value="<?php echo e($product->quantity); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="unit_price" class="form-label">Unit Price</label>
                        <input type="number" name="products[<?php echo e($index); ?>][unit_price]" class="form-control unit_price" step="0.01" value="<?php echo e($product->unit_price); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="total_price" class="form-label">Total Price</label>
                        <input type="number" name="products[<?php echo e($index); ?>][total_price]" class="form-control total_price" step="0.01" value="<?php echo e($product->total_price); ?>" readonly>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <button type="button" id="add-product" class="btn btn-secondary mb-3">Add Another Product</button>
        <button type="submit" class="btn btn-primary">Update Sale</button>
    </form>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        function updateTotalPrice() {
            document.querySelectorAll('.product').forEach(function(productDiv) {
                const quantityInput = productDiv.querySelector('.quantity');
                const unitPriceInput = productDiv.querySelector('.unit_price');
                const totalPriceInput = productDiv.querySelector('.total_price');
                
                quantityInput.addEventListener('input', function() {
                    const quantity = parseFloat(quantityInput.value) || 0;
                    const unitPrice = parseFloat(unitPriceInput.value) || 0;
                    totalPriceInput.value = (quantity * unitPrice).toFixed(2);
                });

                unitPriceInput.addEventListener('input', function() {
                    const quantity = parseFloat(quantityInput.value) || 0;
                    const unitPrice = parseFloat(unitPriceInput.value) || 0;
                    totalPriceInput.value = (quantity * unitPrice).toFixed(2);
                });
            });
        }

        document.getElementById('add-product').addEventListener('click', function() {
            var container = document.getElementById('products-container');
            var index = container.getElementsByClassName('product').length;

            var newProductHtml = `
                <div class="product mb-4 border p-3 rounded">
                    <h5 class="mb-3">Product Details</h5>
                    <div class="mb-3">
                        <label for="stock_id" class="form-label">Product</label>
                        <select name="products[${index}][stock_id]" class="form-select stock_id" required>
                            <option value="">Select a product</option>
                            <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($stock->id); ?>"><?php echo e($stock->item_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="quantity" class="form-label">Quantity</label>
                        <input type="number" name="products[${index}][quantity]" class="form-control quantity" required>
                    </div>

                    <div class="mb-3">
                        <label for="unit_price" class="form-label">Unit Price</label>
                        <input type="number" name="products[${index}][unit_price]" class="form-control unit_price" step="0.01" required>
                    </div>

                    <div class="mb-3">
                        <label for="total_price" class="form-label">Total Price</label>
                        <input type="number" name="products[${index}][total_price]" class="form-control total_price" step="0.01" readonly>
                    </div>
                </div>
            `;

            container.insertAdjacentHTML('beforeend', newProductHtml);
            updateTotalPrice();
        });

        updateTotalPrice();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Downloads\unilakefinalyearproject-main\unilakefinalyearproject-main\resources\views/admin/sales/edit.blade.php ENDPATH**/ ?>