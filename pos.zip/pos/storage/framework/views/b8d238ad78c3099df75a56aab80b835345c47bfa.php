

<?php $__env->startSection('content'); ?>
<section class="section-container">
    <div class="content-wrapper">
        <div class="content-heading">
           ```blade
            <div>View Company Details</div>
        </div>
        <div class="container-fluid">
            <div class="card">
                <div class="card-header">
                    <div class="card-title">Company Information</div>
                </div>
                <div class="card-body">
                    <div class="form-group row">
                        <label class="col-md-4 col-form-label text-md-right">Company Name:</label>
                        <div class="col-md-6">
                            <p class="form-control-plaintext"><?php echo e($company->name); ?></p>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-4 col-form-label text-md-right">Address:</label>
                        <div class="col-md-6">
                            <p class="form-control-plaintext"><?php echo e($company->address); ?></p>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-4 col-form-label text-md-right">Phone:</label>
                        <div class="col-md-6">
                            <p class="form-control-plaintext"><?php echo e($company->phone); ?></p>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-4 col-form-label text-md-right">Email:</label>
                        <div class="col-md-6">
                            <p class="form-control-plaintext"><?php echo e($company->email); ?></p>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-4 col-form-label text-md-right">Website:</label>
                        <div class="col-md-6">
                            <p class="form-control-plaintext"><?php echo e($company->website); ?></p>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-4 col-form-label text-md-right">Status:</label>
                        <div class="col-md-6">
                            <p class="form-control-plaintext"><?php echo e(ucfirst($company->status)); ?></p>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-4 col-form-label text-md-right">Created By:</label>
                        <div class="col-md-6">
                            <p class="form-control-plaintext"><?php echo e($company->createdBy ? $company->createdBy->name : 'N/A'); ?></p>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-6 offset-md-4">
                            <a href="<?php echo e(route('companies.index')); ?>" class="btn btn-secondary">Back to List</a>
                            <a href="<?php echo e(route('companies.edit', $company->id)); ?>" class="btn btn-primary">Edit Company</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Downloads\unilakefinalyearproject-main\unilakefinalyearproject-main\resources\views/admin/companies/show.blade.php ENDPATH**/ ?>