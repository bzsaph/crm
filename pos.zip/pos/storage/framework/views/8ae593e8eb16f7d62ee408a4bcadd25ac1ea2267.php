

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Create Client</h1>

    <form action="<?php echo e(route('clients.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <!-- Name -->
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" id="name" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required>
        </div>

        <!-- Email -->
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" required>
        </div>

        <!-- Phone -->
        <div class="form-group">
            <label for="phone">Phone</label>
            <input type="text" id="phone" name="phone" class="form-control" value="<?php echo e(old('phone')); ?>">
        </div>

        <!-- Managed By -->
        <div class="form-group">
            <label for="managed_by">Managed By</label>
            <select id="managed_by" name="managed_by" class="form-control">
                <option value="">Select User</option>
                <?php $__currentLoopData = $activeUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>" <?php echo e(old('managed_by') == $user->id ? 'selected' : ''); ?>>
                        <?php echo e($user->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Status -->
        <div class="form-group">
            <label for="status">Status</label>
            <select id="status" name="status" class="form-control">
                <option value="1" <?php echo e(old('status') == '1' ? 'selected' : ''); ?>>Active</option>
                <option value="0" <?php echo e(old('status') == '0' ? 'selected' : ''); ?>>Inactive</option>
            </select>
        </div>

        <!-- Client Type -->
        <div class="form-group">
            <label for="client_type">Client Type</label>
            <select id="client_type" name="client_type" class="form-control">
                <option value="vendor" <?php echo e(old('client_type') == 'vendor' ? 'selected' : ''); ?>>Vendor</option>
                <option value="client" <?php echo e(old('client_type') == 'client' ? 'selected' : ''); ?>>Client</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Create Client</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Downloads\unilakefinalyearproject-main\unilakefinalyearproject-main\resources\views/admin/clients/create.blade.php ENDPATH**/ ?>