

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Clients</h1>
    <a href="<?php echo e(route('clients.create')); ?>" class="btn btn-primary">Add New Client</a>
    <table class="table table-striped mt-4">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Managed By</th>
                <th>Status</th>
                <th>User ID</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($client->id); ?></td>
                <td><?php echo e($client->name); ?></td>
                <td><?php echo e($client->email); ?></td>
                <td><?php echo e($client->phone); ?></td>
                <td><?php echo e($client->managed_by); ?></td>
                <td><?php echo e($client->status == 1 ? 'Active' : 'Inactive'); ?></td>
                <td><?php echo e($client->user_id); ?></td>
                <td>
                    <a href="<?php echo e(route('clients.edit', $client->id)); ?>" class="btn btn-warning">Edit</a>
                    <form action="<?php echo e(route('clients.destroy', $client->id)); ?>" method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Downloads\unilakefinalyearproject-main\unilakefinalyearproject-main\resources\views/admin/clients/index.blade.php ENDPATH**/ ?>