

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Complaints</h1>
    <a href="<?php echo e(route('complaints.create')); ?>" class="btn btn-primary">Add New Complaint</a>
    <table class="table table-striped mt-4">
        <thead>
            <tr>
                <th>ID</th>
              
                <th>Complaint Content</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $complaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complaint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($complaint->id); ?></td>
                <td><?php echo e($complaint->complaint_text); ?></td>
                <td><?php echo e($complaint->status == 1 ? 'Resolved' : 'Pending'); ?></td>
                <td>
                    <a href="<?php echo e(route('complaints.edit', $complaint->id)); ?>" class="btn btn-warning">Edit</a>
                    
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Downloads\unilakefinalyearproject-main\pos\resources\views/admin/complaints/index.blade.php ENDPATH**/ ?>