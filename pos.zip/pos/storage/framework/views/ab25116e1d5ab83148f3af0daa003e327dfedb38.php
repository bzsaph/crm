

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Client</h1>
    <form action="<?php echo e(route('clients.update', $client->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($client->name); ?>" required>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo e($client->email); ?>" required>
        </div>
        <div class="form-group">
            <label for="phone">Phone</label>
            <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e($client->phone); ?>">
        </div>
        <div class="form-group">
            <label for="managed_by">Managed By</label>
            <input type="text" class="form-control" id="managed_by" name="managed_by" value="<?php echo e($client->managed_by); ?>">
        </div>
        <div class="form-group">
            <label for="status">Status</label>
            <select class="form-control" id="status" name="status">
                <option value="1" <?php echo e($client->status == 1 ? 'selected' : ''); ?>>Active</option>
                <option value="0" <?php echo e($client->status == 0 ? 'selected' : ''); ?>>Inactive</option>
            </select>
        </div>
        <div class="form-group">
            <label for="user_id">User ID</label>
            <input type="text" class="form-control" id="user_id" name="user_id" value="<?php echo e($client->user_id); ?>">
        </div>
        <button type="submit" class="btn btn-primary">Update Client</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Downloads\unilakefinalyearproject-main\unilakefinalyearproject-main\resources\views/admin/clients/edit.blade.php ENDPATH**/ ?>