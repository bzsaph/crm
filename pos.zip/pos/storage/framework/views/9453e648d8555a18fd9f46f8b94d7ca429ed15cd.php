

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1 class="mb-4">Sales List</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="mb-4">
        <a href="<?php echo e(route('sales.create')); ?>" class="btn btn-primary">Add New Sale</a>
    </div>

    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Client</th>
                    <th>Invoice Number</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($sale->id); ?></td>
                        <td><?php echo e($sale->client_name); ?></td>
                        <td><?php echo e($sale->invoice_number ?? 'N/A'); ?></td> <!-- Handle missing invoice_number -->
                        <td><?php echo e(\Carbon\Carbon::now()->format('d/m/Y')); ?></td> <!-- Replace with actual sale date if available -->
                        <td>
                            <a href="<?php echo e(route('sales.show', $sale->id)); ?>" class="btn btn-info btn-sm">View</a>
                            <a href="<?php echo e(route('sales.edit', $sale->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                           
                            <a href="<?php echo e(route('sales.invoice', $sale->id)); ?>" class="btn btn-success btn-sm">Invoice</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center">No sales records found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Downloads\unilakefinalyearproject-main\pos\resources\views/admin/sales/index.blade.php ENDPATH**/ ?>