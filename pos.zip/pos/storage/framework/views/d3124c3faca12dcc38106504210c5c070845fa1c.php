

<?php $__env->startSection('content'); ?>

<section class="section-container">
    <div class="content-wrapper">
       <div class="content-heading">
          <div>All users in the system</div>
       </div>
       <div class="container-fluid">
          <div class="card">
             <div class="card-header">
                <div class="card-title">All users</div>
             </div>
             <div class="card-body">
                <table class="table table-striped my-4 w-100" id="datatable2">
                    <caption style="caption-side: top; text-align: center"><?php echo e(Auth::user()->name); ?></caption>
                   <thead>
                      <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Company</th>
                        <th>Create Date</th>
                        <th>Action</th>
                      </tr>
                   </thead>
                   <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo $item->email; ?></td>
                        <td>
                           <?php echo e($item->company_name ?? 'No company assigned'); ?>

                       </td>
                        <td><?php echo e($item->created_at); ?></td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-update')): ?>
                                <a href="<?php echo e(route('users.edit', $item->id)); ?>" class="btn btn-success" id="alert-success">Edit</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </tbody>
                </table>
             </div>
          </div>
       </div>
    </div>
 </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Downloads\unilakefinalyearproject-main\unilakefinalyearproject-main\resources\views/admin/users/index.blade.php ENDPATH**/ ?>