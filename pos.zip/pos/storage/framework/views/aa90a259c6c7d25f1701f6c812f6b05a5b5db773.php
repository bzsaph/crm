 <?php if($message = Session::get('message')): ?>
                            <div class="alert alert-success">
                            <ul>
                                    <?php echo e($message); ?>

                            </ul>
                            </div>
                            <?php endif; ?>
        <div class="container-fluid">
<?php $__env->startSection('content'); ?>
<!-- Main section-->
<section class="section-container">
    <!-- Page content-->
    <div class="content-wrapper">
        <div class="content-heading">
            <div>Settings

            </div>
        </div>

        <!-- START row-->
        <div class="row">
            <div class="col-lg-12">
                <div class="col-lg-12">



                        <table id="permissions-table" class="table table-responsive table-hover table_wrapper">

                                <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <thead>
                                    <tr>
                                        <th></th>
                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th><?php echo e($permi->name); ?></th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <form class="form-horizontal" action="roleupdate/<?php echo e($roles->id); ?>" method="POST">
                                        <?php echo csrf_field(); ?>

                                        <input type="hidden" name="role_id" value="4">
                                        <tr>
                                            <th><?php echo e($roles->name); ?></th>

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td>
                                                    <input type="checkbox" name="permissions[]" value="<?php echo e($permi->id); ?>" <?php if($roles->permissions->contains($permi)): ?> checked <?php endif; ?>>
                                                   <span class="perm-name"></span><br></td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <th></th>
                                            <td><input type="submit" value="Save Role" class="btn btn-primary"></td>
                                        </tr>
                                    </form>
                                </tbody>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>

                </div>
            </div>
        </div>
        <!-- END row-->
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Downloads\unilakefinalyearproject-main\unilakefinalyearproject-main\resources\views/admin/setting.blade.php ENDPATH**/ ?>