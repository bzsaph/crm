@extends('layouts.adminapp')
@section('content')

@section('content')
    <h1>Client Details: {{ $client->name }}</h1>
    <!-- Display client details and related billing, tasks, etc. -->
@endsection
