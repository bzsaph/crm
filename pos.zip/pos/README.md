$ php artisan db:seed --class=Roleseeder
Database seeding completed successfully.


$ php artisan db:seed --class=Permissionseeder
Database seeding completed successfully.


$ php artisan db:seed --class=UserSeeder 
&& php artisan db:seed --class=Roleseeder 
&&php artisan db:seed --class=Permissionseeder 
&& php artisan db:seed --class=Giveparmission
Database seeding completed successfully.

$ php artisan db:seed --class=Giveparmission


HP@DESKTOP-N9DUCQC MINGW64 ~/Downloads/unilakefinalyearproject-main/unilakefinalyearproject-main (main)
$ npm uninstall micromatch fast-glob globby http-proxy-middleware webpack-dev-server imagemin laravel-mix

removed 637 packages, and audited 149 packages in 3s

20 packages are looking for funding
  run `npm fund` for details

found 0 vulnerabilities

HP@DESKTOP-N9DUCQC MINGW64 ~/Downloads/unilakefinalyearproject-main/unilakefinalyearproject-main (main)
$ npm install minimatch http-proxy sharp vite
